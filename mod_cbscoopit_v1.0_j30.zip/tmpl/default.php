<?php
    /* ------------------------------------------------------------------------
   # default.php - Module - mod_cbscoopit
   # ------------------------------------------------------------------------
   # author    Codeboxr Team
   # copyright Copyright (C) 2010-2012 codeboxr.com. All Rights Reserved.
   # @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
   # Websites: http://codeboxr.com
   # Technical Support:  Forum - coming soon
   ------------------------------------------------------------------------- */
    // No direct access
   // defined ('_JEXEC') or die;
?>
<iframe
    src='//www.scoop.it/embed-topic/<?php echo $scooitId ?>.html?maxwidth=<?php echo $maxwidth ?>'
    width='<?php echo $maxwidth ?>'
    height='<?php echo $height ?>'
    scrolling='no'>

</iframe>

